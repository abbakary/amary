new EmojiPicker({
  trigger: [
    {
      selector: ".second-btn",
      insertInto: ".two",
    },
  ],
  closeButton: true,
  //specialButtons: green
});
